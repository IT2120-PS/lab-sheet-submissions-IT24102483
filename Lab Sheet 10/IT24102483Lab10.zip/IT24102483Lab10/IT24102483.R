setwd("C:\\Users\\sasmi\\OneDrive\\Documents\\Downloads\\IT24102483Lab10")

observed_counts <- c(120, 95, 85, 100)

chisq.test(x = observed_counts)
